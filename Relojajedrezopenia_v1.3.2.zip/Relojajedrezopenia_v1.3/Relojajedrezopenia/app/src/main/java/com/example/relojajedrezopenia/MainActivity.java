package com.example.relojajedrezopenia;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private Button playerOneTimerView, playerTwoTimerView, startButton, menuButton, judgeButton;
    private TextView whitePlayerMovesView, blackPlayerMovesView;
    private CountDownTimer gameTimer;
    private long playerOneTimeLeft = 30000; // 30 segundos en milisegundos
    private long playerTwoTimeLeft = 30000; // 30 segundos en milisegundos
    private int whitePlayerMoves = 0; // Contador para las jugadas del jugador blanco
    private int blackPlayerMoves = 0; // Contador para las jugadas del jugador negro
    private boolean isPlayerOneTurn = true;
    private boolean isGameStarted = false;
    private boolean isGameRunning = false;
    private boolean isGamePaused = false;

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private static final int SETTINGS_REQUEST = 1;
    public static final String EXTRA_PLAYER_ONE_TIME = "EXTRA_PLAYER_ONE_TIME";
    public static final String EXTRA_PLAYER_TWO_TIME = "EXTRA_PLAYER_TWO_TIME";
    public static final String EXTRA_INCREMENT_WHITE = "EXTRA_INCREMENT_WHITE"; // Nuevo extra para incremento de blancas
    public static final String EXTRA_INCREMENT_BLACK = "EXTRA_INCREMENT_BLACK"; // Nuevo extra para incremento de negras

    private static final long MOVE_THRESHOLD_TIME = 250; // Umbral de tiempo para evitar múltiples conteos
    private long lastMoveTime = 0;

    private int incrementWhite = 0; // Nuevo campo para incremento de blancas
    private int incrementBlack = 0; // Nuevo campo para incremento de negras

    private boolean isMoveMade = false; // Nuevo campo para rastrear si se realizó una jugada

    // Constantes para guardar/restaurar estado
    private static final String STATE_PLAYER_ONE_TIME_LEFT = "playerOneTimeLeft";
    private static final String STATE_PLAYER_TWO_TIME_LEFT = "playerTwoTimeLeft";
    private static final String STATE_WHITE_PLAYER_MOVES = "whitePlayerMoves";
    private static final String STATE_BLACK_PLAYER_MOVES = "blackPlayerMoves";
    private static final String STATE_IS_PLAYER_ONE_TURN = "isPlayerOneTurn";
    private static final String STATE_IS_GAME_STARTED = "isGameStarted";
    private static final String STATE_IS_GAME_RUNNING = "isGameRunning";
    private static final String STATE_IS_GAME_PAUSED = "isGamePaused";
    private static final String STATE_INCREMENT_WHITE = "incrementWhite"; // Nuevo estado para incremento de blancas
    private static final String STATE_INCREMENT_BLACK = "incrementBlack"; // Nuevo estado para incremento de negras

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        playerOneTimerView = findViewById(R.id.playerOneTimer);
        playerTwoTimerView = findViewById(R.id.playerTwoTimer);
        whitePlayerMovesView = findViewById(R.id.whitePlayerMoves);
        blackPlayerMovesView = findViewById(R.id.blackPlayerMoves);
        startButton = findViewById(R.id.startButton);
        menuButton = findViewById(R.id.menuButton);
        judgeButton = findViewById(R.id.judgeButton);

        if (savedInstanceState != null) {
            playerOneTimeLeft = savedInstanceState.getLong(STATE_PLAYER_ONE_TIME_LEFT);
            playerTwoTimeLeft = savedInstanceState.getLong(STATE_PLAYER_TWO_TIME_LEFT);
            whitePlayerMoves = savedInstanceState.getInt(STATE_WHITE_PLAYER_MOVES);
            blackPlayerMoves = savedInstanceState.getInt(STATE_BLACK_PLAYER_MOVES);
            isPlayerOneTurn = savedInstanceState.getBoolean(STATE_IS_PLAYER_ONE_TURN);
            isGameStarted = savedInstanceState.getBoolean(STATE_IS_GAME_STARTED);
            isGameRunning = savedInstanceState.getBoolean(STATE_IS_GAME_RUNNING);
            isGamePaused = savedInstanceState.getBoolean(STATE_IS_GAME_PAUSED);
            incrementWhite = savedInstanceState.getInt(STATE_INCREMENT_WHITE); // Restaurar incremento de blancas
            incrementBlack = savedInstanceState.getInt(STATE_INCREMENT_BLACK); // Restaurar incremento de negras
        } else {
            Intent intent = getIntent();
            playerOneTimeLeft = intent.getLongExtra(EXTRA_PLAYER_ONE_TIME, 30000);
            playerTwoTimeLeft = intent.getLongExtra(EXTRA_PLAYER_TWO_TIME, 30000);
            incrementWhite = intent.getIntExtra(EXTRA_INCREMENT_WHITE, 0); // Obtener incremento para blancas
            incrementBlack = intent.getIntExtra(EXTRA_INCREMENT_BLACK, 0); // Obtener incremento para negras
        }

        updateTimerText(playerOneTimeLeft, 1);
        updateTimerText(playerTwoTimeLeft, 2);
        updateMoveCount();

        gameTimer = createTimer();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleStartButton();
            }
        });

        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivityForResult(intent, SETTINGS_REQUEST);
            }
        });

        judgeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleJudgeButton();
            }
        });
    }

    private void handleStartButton() {
        if (!isGameRunning) {
            isGameRunning = true;
            startButton.setEnabled(false);
            isGameStarted = true;
            gameTimer.start();

            whitePlayerMoves = 0;
            blackPlayerMoves = 0;
            updateMoveCount();
        }
    }

    private void handleJudgeButton() {
        if (isGameRunning) {
            isGamePaused = !isGamePaused;
        }
    }

    private CountDownTimer createTimer() {
        return new CountDownTimer(Long.MAX_VALUE, 1000) {
            public void onTick(long millisUntilFinished) {
                if (isGamePaused) return;

                if (isPlayerOneTurn) {
                    if (playerOneTimeLeft <= 0) {
                        onFinishGame();
                        return;
                    }
                    playerOneTimeLeft -= 1000;
                } else {
                    if (playerTwoTimeLeft <= 0) {
                        onFinishGame();
                        return;
                    }
                    playerTwoTimeLeft -= 1000;
                }
                updateTimerTexts();
            }

            public void onFinish() {
            }

            private void onFinishGame() {
                isGameRunning = false;
                isGameStarted = false;
                cancel();
                updateTimerTexts();
                startButton.setEnabled(true);
            }
        };
    }

    private void updateTimerTexts() {
        updateTimerText(playerOneTimeLeft, 1);
        updateTimerText(playerTwoTimeLeft, 2);
    }

    private void updateTimerText(long timeLeft, int playerId) {
        String timerText = String.format("%02d:%02d", (timeLeft / 1000) / 60, (timeLeft / 1000) % 60);
        if (playerId == 1) {
            playerOneTimerView.setText(timerText);
        } else {
            playerTwoTimerView.setText(timerText);
        }
    }

    private void updateMoveCount() {
        whitePlayerMovesView.setText("Blancas: " + whitePlayerMoves);
        blackPlayerMovesView.setText("Negras: " + blackPlayerMoves);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!isGameStarted || System.currentTimeMillis() - lastMoveTime < MOVE_THRESHOLD_TIME) return;

        float y = event.values[1];
        if ((y > 0.2 && !isPlayerOneTurn) || (y < 0.2 && isPlayerOneTurn)) {
            lastMoveTime = System.currentTimeMillis();

            // Aplicar el incremento antes de cambiar el turno
            if (isPlayerOneTurn) {
                playerOneTimeLeft += incrementWhite * 1000; // Incremento para blancas
                whitePlayerMoves++;
            } else {
                playerTwoTimeLeft += incrementBlack * 1000; // Incremento para negras
                blackPlayerMoves++;
            }

            // Cambiar el turno después de aplicar el incremento
            isPlayerOneTurn = !isPlayerOneTurn;
            updateMoveCount();

            isMoveMade = true;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        gameTimer.cancel();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        if (isGameStarted) {
            gameTimer.start();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(STATE_PLAYER_ONE_TIME_LEFT, playerOneTimeLeft);
        outState.putLong(STATE_PLAYER_TWO_TIME_LEFT, playerTwoTimeLeft);
        outState.putInt(STATE_WHITE_PLAYER_MOVES, whitePlayerMoves);
        outState.putInt(STATE_BLACK_PLAYER_MOVES, blackPlayerMoves);
        outState.putBoolean(STATE_IS_PLAYER_ONE_TURN, isPlayerOneTurn);
        outState.putBoolean(STATE_IS_GAME_STARTED, isGameStarted);
        outState.putBoolean(STATE_IS_GAME_RUNNING, isGameRunning);
        outState.putBoolean(STATE_IS_GAME_PAUSED, isGamePaused);
        outState.putInt(STATE_INCREMENT_WHITE, incrementWhite); // Guardar incremento de blancas
        outState.putInt(STATE_INCREMENT_BLACK, incrementBlack); // Guardar incremento de negras
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SETTINGS_REQUEST && resultCode == RESULT_OK) {
            playerOneTimeLeft = data.getLongExtra(EXTRA_PLAYER_ONE_TIME, 30000);
            playerTwoTimeLeft = data.getLongExtra(EXTRA_PLAYER_TWO_TIME, 30000);
            incrementWhite = data.getIntExtra(EXTRA_INCREMENT_WHITE, 0); // Obtener incremento para blancas
            incrementBlack = data.getIntExtra(EXTRA_INCREMENT_BLACK, 0); // Obtener incremento para negras
            updateTimerTexts();
        }
    }
}
