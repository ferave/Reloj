package com.example.relojajedrezopenia;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class MenuActivity extends AppCompatActivity {

    private float currentRotationAngle = 0f; // Ángulo de rotación actual de los textos de los botones

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Restaurar el estado de rotación si existe
        if (savedInstanceState != null) {
            currentRotationAngle = savedInstanceState.getFloat("rotation_angle", 0f);
        }

        // Aplica la rotación actual a los botones
        rotateButtonText(currentRotationAngle);

        // Configuración de botones y otros componentes de la UI
        setupButtons();
    }

    private void setupButtons() {
        Button buttonBullet1 = findViewById(R.id.button_bullet_1);
        Button buttonBullet2 = findViewById(R.id.button_bullet_2);
        Button button_blitz_3 = findViewById(R.id.button_blitz_3);
        Button buttonCustom = findViewById(R.id.button_custom);
        Button button_blitz_3_2 = findViewById(R.id.button_blitz_3_2);
        Button button_blitz_5 = findViewById(R.id.button_blitz_5);
        Button button_blitz_5_3 = findViewById(R.id.button_blitz_5_3);
        Button button_rapid_10 = findViewById(R.id.button_rapid_10);
        Button button_rapid_10_5 = findViewById(R.id.button_rapid_10_5);
        Button button_rapid_15_10 = findViewById(R.id.button_rapid_15_10);
        Button button_classical_30 = findViewById(R.id.button_classical_30);
        Button button_classical_30_20 = findViewById(R.id.button_classical_30_20);

        buttonCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        buttonBullet1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 1;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 1;
                int seconds2 = 0;
                int incrementWhite = 0;
                int incrementBlack =0;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        buttonBullet2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 2;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 2;
                int seconds2 = 0;
                int incrementWhite = 1;
                int incrementBlack =1;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_blitz_3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 3;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 3;
                int seconds2 = 0;
                int incrementWhite = 0;
                int incrementBlack =0;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_blitz_3_2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 3;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 3;
                int seconds2 = 0;
                int incrementWhite = 2;
                int incrementBlack = 2;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_blitz_5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 5;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 5;
                int seconds2 = 0;
                int incrementWhite = 0;
                int incrementBlack = 0;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_blitz_5_3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 5;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 5;
                int seconds2 = 0;
                int incrementWhite = 3;
                int incrementBlack = 3;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_rapid_10.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 10;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 10;
                int seconds2 = 0;
                int incrementWhite = 0;
                int incrementBlack = 0;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_rapid_10_5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 10;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 10;
                int seconds2 = 0;
                int incrementWhite = 5;
                int incrementBlack = 5;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_rapid_15_10.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 15;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 15;
                int seconds2 = 0;
                int incrementWhite = 10;
                int incrementBlack = 10;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_classical_30.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 30;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 30;
                int seconds2 = 0;
                int incrementWhite = 0;
                int incrementBlack = 0;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });

        button_classical_30_20.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Obtener valores de los campos de entrada
                int hours1 = 0;
                int minutes1 = 30;
                int seconds1 = 0;
                int hours2 = 0;
                int minutes2 = 30;
                int seconds2 = 0;
                int incrementWhite = 20;
                int incrementBlack = 20;

                // Calcular el tiempo total en segundos para ambos jugadores
                int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                // Validar que los valores sean no negativos

                Intent mainActivityIntent = new Intent(MenuActivity.this, MainActivity.class);
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                startActivity(mainActivityIntent);

            }
        });
        // Configura los oyentes para otros botones de manera similar...
        // Por ejemplo, para el botón "button_bullet_2", puedes configurar otro conjunto de tiempos
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Revisa la orientación actual y ajusta tu UI como sea necesario
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Código para cuando está en orientación horizontal
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            // Código para cuando está en orientación vertical
        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Guarda el ángulo de rotación actual
        outState.putFloat("rotation_angle", currentRotationAngle);
    }

    private void rotateButtonText(float angle) {
        int[] buttonIds = new int[] {
                R.id.button_bullet_1, R.id.button_bullet_2, R.id.button_custom // ... agregar todos los IDs de botones aquí
        };

        for (int id : buttonIds) {
            Button button = findViewById(id);
            button.setRotation(angle);
        }
    }
}
