package com.example.relojajedrezopenia;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class aActivity extends Activity {

    private Button startButton, button_bullet_1;
    private EditText playerOneHourInput, playerOneMinuteInput, playerOneSecondInput;
    private EditText playerTwoHourInput, playerTwoMinuteInput, playerTwoSecondInput;
    private EditText incrementWhiteInput, incrementBlackInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);

        // Inicializar vistas y botones
        button_bullet_1 = findViewById(R.id.button_bullet_1);


        // Configurar el botón de inicio
        button_bullet_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    // Obtener valores de los campos de entrada
                    int hours1 = 2;
                    int minutes1 = 2;
                    int seconds1 = 2;
                    int hours2 = 2;
                    int minutes2 = 2;
                    int seconds2 = 2;
                    int incrementWhite = 2;
                    int incrementBlack =2;

                    // Calcular el tiempo total en segundos para ambos jugadores
                    int totalSeconds1 = hours1 * 3600 + minutes1 * 60 + seconds1;
                    int totalSeconds2 = hours2 * 3600 + minutes2 * 60 + seconds2;

                    // Validar que los valores sean no negativos

                        Intent mainActivityIntent = new Intent(aActivity.this, MainActivity.class);
                        mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                        mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                        mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite);
                        mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack);

                        startActivity(mainActivityIntent);

            }

        });
    }
}
