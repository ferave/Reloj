package com.example.relojajedrezopenia;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SettingsActivity extends Activity {

    private EditText playerOneHourInput, playerOneMinuteInput, playerOneSecondInput;
    private EditText playerTwoHourInput, playerTwoMinuteInput, playerTwoSecondInput;
    private EditText incrementWhiteInput, incrementBlackInput; // Nuevos campos para incremento
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Inicializa los campos EditText
        playerOneHourInput = findViewById(R.id.playerOneHourInput);
        playerOneMinuteInput = findViewById(R.id.playerOneMinuteInput);
        playerOneSecondInput = findViewById(R.id.playerOneSecondInput);
        playerTwoHourInput = findViewById(R.id.playerTwoHourInput);
        playerTwoMinuteInput = findViewById(R.id.playerTwoMinuteInput);
        playerTwoSecondInput = findViewById(R.id.playerTwoSecondInput);
        incrementWhiteInput = findViewById(R.id.incrementWhiteInput); // Nuevo campo de incremento para blancas
        incrementBlackInput = findViewById(R.id.incrementBlackInput); // Nuevo campo de incremento para negras

        // Cargar configuraciones guardadas
        cargarConfiguraciones();

        saveButton = findViewById(R.id.saveSettingsButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validarEntrada()) {
                    Toast.makeText(SettingsActivity.this, "Error: Please fill in all fields with numeric values.", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int totalSeconds1 = obtenerSegundosTotalesDeEntrada(playerOneHourInput, playerOneMinuteInput, playerOneSecondInput);
                    int totalSeconds2 = obtenerSegundosTotalesDeEntrada(playerTwoHourInput, playerTwoMinuteInput, playerTwoSecondInput);
                    int incrementWhite = obtenerIncremento(incrementWhiteInput); // Obtener incremento para blancas
                    int incrementBlack = obtenerIncremento(incrementBlackInput); // Obtener incremento para negras

                    // Guardar configuraciones
                    guardarConfiguraciones(totalSeconds1, totalSeconds2, incrementWhite, incrementBlack);

                    Intent mainActivityIntent = new Intent(SettingsActivity.this, MainActivity.class);
                    mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_ONE_TIME, totalSeconds1 * 1000L); // Convertir a milisegundos
                    mainActivityIntent.putExtra(MainActivity.EXTRA_PLAYER_TWO_TIME, totalSeconds2 * 1000L);
                    mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_WHITE, incrementWhite); // Pasar incremento para blancas
                    mainActivityIntent.putExtra(MainActivity.EXTRA_INCREMENT_BLACK, incrementBlack); // Pasar incremento para negras
                    startActivity(mainActivityIntent);

                } catch (NumberFormatException e) {
                    Toast.makeText(SettingsActivity.this, "Error: Incorrect numeric format.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private boolean validarEntrada() {
        return validarCampo(playerOneHourInput) && validarCampo(playerOneMinuteInput) && validarCampo(playerOneSecondInput)
                && validarCampo(playerTwoHourInput) && validarCampo(playerTwoMinuteInput) && validarCampo(playerTwoSecondInput)
                && validarCampo(incrementWhiteInput) && validarCampo(incrementBlackInput); // Validar campos de incremento
    }

    private boolean validarCampo(EditText editText) {
        String texto = editText.getText().toString();
        return !texto.isEmpty() && texto.matches("\\d+"); // Verifica que no esté vacío y contenga solo dígitos
    }

    private int obtenerSegundosTotalesDeEntrada(EditText hourInput, EditText minuteInput, EditText secondInput) throws NumberFormatException {
        int hours = Integer.parseInt(hourInput.getText().toString());
        int minutes = Integer.parseInt(minuteInput.getText().toString());
        int seconds = Integer.parseInt(secondInput.getText().toString());
        return hours * 3600 + minutes * 60 + seconds;
    }

    private int obtenerIncremento(EditText incrementInput) throws NumberFormatException {
        String incrementText = incrementInput.getText().toString();
        return Integer.parseInt(incrementText);
    }

    private void cargarConfiguraciones() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        // Cargar configuraciones previamente guardadas
        playerOneHourInput.setText(sharedPreferences.getString("playerOneHour", ""));
        playerOneMinuteInput.setText(sharedPreferences.getString("playerOneMinute", ""));
        playerOneSecondInput.setText(sharedPreferences.getString("playerOneSecond", ""));
        playerTwoHourInput.setText(sharedPreferences.getString("playerTwoHour", ""));
        playerTwoMinuteInput.setText(sharedPreferences.getString("playerTwoMinute", ""));
        playerTwoSecondInput.setText(sharedPreferences.getString("playerTwoSecond", ""));
        incrementWhiteInput.setText(sharedPreferences.getString("incrementWhite", ""));
        incrementBlackInput.setText(sharedPreferences.getString("incrementBlack", ""));
    }

    private void guardarConfiguraciones(int totalSeconds1, int totalSeconds2, int incrementWhite, int incrementBlack) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Guardar configuraciones
        editor.putString("playerOneHour", String.valueOf(totalSeconds1 / 3600));
        editor.putString("playerOneMinute", String.valueOf((totalSeconds1 % 3600) / 60));
        editor.putString("playerOneSecond", String.valueOf(totalSeconds1 % 60));
        editor.putString("playerTwoHour", String.valueOf(totalSeconds2 / 3600));
        editor.putString("playerTwoMinute", String.valueOf((totalSeconds2 % 3600) / 60));
        editor.putString("playerTwoSecond", String.valueOf(totalSeconds2 % 60));
        editor.putString("incrementWhite", String.valueOf(incrementWhite));
        editor.putString("incrementBlack", String.valueOf(incrementBlack));

        editor.apply();
    }

}
