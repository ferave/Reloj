package com.example.relojajedrezopenia;

import android.app.Activity;

public class PasswdActivity extends Activity {


}
