package com.example.relojajedrezopenia;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedList;
import java.util.Queue;



public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private Button startButton, menuButton, judgeButton, optionsButton;
    private TextView playerOneTimerView, playerTwoTimerView, whitePlayerMovesView, blackPlayerMovesView;
    private CountDownTimer gameTimer;
    private long playerOneTimeLeft = 30000; // 30 segundos en milisegundos
    private long playerTwoTimeLeft = 30000; // 30 segundos en milisegundos
    private int whitePlayerMoves = 0; // Contador para las jugadas del jugador blanco
    private int blackPlayerMoves = 0; // Contador para las jugadas del jugador negro
    private boolean isPlayerOneTurn = true;
    private boolean isGameRunning = false;
    private boolean isGamePaused = false;

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private static final int SETTINGS_REQUEST = 1;
    public static final String EXTRA_PLAYER_ONE_TIME = "EXTRA_PLAYER_ONE_TIME";
    public static final String EXTRA_PLAYER_TWO_TIME = "EXTRA_PLAYER_TWO_TIME";
    public static final String EXTRA_INCREMENT_WHITE = "EXTRA_INCREMENT_WHITE"; // Nuevo extra para incremento de blancas
    public static final String EXTRA_INCREMENT_BLACK = "EXTRA_INCREMENT_BLACK"; // Nuevo extra para incremento de negras


    private long lastMoveTime = 0;

    private int incrementWhite = 0; // Nuevo campo para incremento de blancas
    private int incrementBlack = 0; // Nuevo campo para incremento de negras

    private MediaPlayer mediaPlayer; // Agregar esta variable

    // Constantes para guardar/restaurar estado
    private static final String STATE_PLAYER_ONE_TIME_LEFT = "playerOneTimeLeft";
    private static final String STATE_PLAYER_TWO_TIME_LEFT = "playerTwoTimeLeft";
    private static final String STATE_WHITE_PLAYER_MOVES = "whitePlayerMoves";
    private static final String STATE_BLACK_PLAYER_MOVES = "blackPlayerMoves";
    private static final String STATE_IS_PLAYER_ONE_TURN = "isPlayerOneTurn";
    private static final String STATE_IS_GAME_RUNNING = "isGameRunning";
    private static final String STATE_IS_GAME_PAUSED = "isGamePaused";
    private static final String STATE_INCREMENT_WHITE = "incrementWhite"; // Nuevo estado para incremento de blancas
    private static final String STATE_INCREMENT_BLACK = "incrementBlack"; // Nuevo estado para incremento de negras

    private TextView playerOneIncrementView;
    private TextView playerTwoIncrementView;

    private Queue<Float> accelerationQueue = new LinkedList<>();
    private static final int WINDOW_SIZE = 5; // Tamaño de la ventana para el promedio móvil

    // Variables para el filtro de paso bajo y detección de umbral
    private static final float ALPHA = 0.2f; // Factor para el filtro de paso bajo
    private static final float THRESHOLD = 2f; // Umbral para la detección de golpes
    private float filteredY = 0; // Valor filtrado del acelerómetro en el eje Y
    private static final long MOVE_THRESHOLD_TIME = 30; // Umbral de tiempo para evitar múltiples conteos


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Mantener la pantalla encendida
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Ocultar la barra de navegación y poner la app en pantalla completa
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        // Ocultar los botones de navegación
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_main);

        // Inicializar vistas y botones
        playerOneTimerView = findViewById(R.id.playerOneTimer);
        playerTwoTimerView = findViewById(R.id.playerTwoTimer);
        whitePlayerMovesView = findViewById(R.id.whitePlayerMoves);
        blackPlayerMovesView = findViewById(R.id.blackPlayerMoves);
        startButton = findViewById(R.id.startButton);
        //menuButton = findViewById(R.id.menuButton);
        judgeButton = findViewById(R.id.judgeButton);
        optionsButton = findViewById(R.id.optionsButton);

        // Restaurar valores de estado si es necesario
        if (savedInstanceState != null) {
            playerOneTimeLeft = savedInstanceState.getLong(STATE_PLAYER_ONE_TIME_LEFT);
            playerTwoTimeLeft = savedInstanceState.getLong(STATE_PLAYER_TWO_TIME_LEFT);
            whitePlayerMoves = savedInstanceState.getInt(STATE_WHITE_PLAYER_MOVES);
            blackPlayerMoves = savedInstanceState.getInt(STATE_BLACK_PLAYER_MOVES);
            isPlayerOneTurn = savedInstanceState.getBoolean(STATE_IS_PLAYER_ONE_TURN);
            isGameRunning = savedInstanceState.getBoolean(STATE_IS_GAME_RUNNING);
            isGamePaused = savedInstanceState.getBoolean(STATE_IS_GAME_PAUSED);
            incrementWhite = savedInstanceState.getInt(STATE_INCREMENT_WHITE); // Restaurar incremento de blancas
            incrementBlack = savedInstanceState.getInt(STATE_INCREMENT_BLACK); // Restaurar incremento de negras
        } else {
            // Obtener valores de los extras si se lanzó desde aActivity
            Intent intent = getIntent();
            playerOneTimeLeft = intent.getLongExtra(EXTRA_PLAYER_ONE_TIME, 300000);
            playerTwoTimeLeft = intent.getLongExtra(EXTRA_PLAYER_TWO_TIME, 300000);
            incrementWhite = intent.getIntExtra(EXTRA_INCREMENT_WHITE, 0); // Obtener incremento para blancas
            incrementBlack = intent.getIntExtra(EXTRA_INCREMENT_BLACK, 0); // Obtener incremento para negras
        }
        playerOneIncrementView = findViewById(R.id.playerOneIncrement);
        playerTwoIncrementView = findViewById(R.id.playerTwoIncrement);

        // Actualizar las vistas con los valores iniciales
        updateTimerText(playerOneTimeLeft, 1);
        updateTimerText(playerTwoTimeLeft, 2);
        updateMoveCount();
        updateIncrementDisplay();

        // Crear el temporizador del juego
        gameTimer = createTimer();

        // Inicializar el sensor de acelerómetro
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);

        // Inicializar el reproductor de audio
        mediaPlayer = MediaPlayer.create(this, R.raw.pitido);

        // Configurar los botones
        startButton.setOnClickListener(v -> handleStartButton());
        //menuButton.setOnClickListener(v -> {
        //    Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
        //    startActivityForResult(intent, SETTINGS_REQUEST);
        //});
        judgeButton.setOnClickListener(v -> handleJudgeButton());
        optionsButton.setOnClickListener(v -> handleMenuButton());

        // Ocultar los botones de navegación
        //View decorView = getWindow().getDecorView();
        //decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    // Método para actualizar los TextViews con los valores de incremento
    private void updateIncrementDisplay() {
        playerOneIncrementView.setText("+ " + incrementWhite +" s");
        playerTwoIncrementView.setText("+ " + incrementBlack +" s");
    }

    private void handleStartButton() {
        if (!isGameRunning) {
            isGameRunning = true;
            startButton.setEnabled(false);
            gameTimer.start();

            whitePlayerMoves = 0;
            blackPlayerMoves = 0;
            updateMoveCount();
            // Deshabilitar los botones de navegación al iniciar el juego
            disableSystemUI();
            // Habilitar el modo avión
            toggleAirplaneMode();
        }
    }

    private void handleJudgeButton() {
        isGamePaused = !isGamePaused;

        if (isGamePaused) {
            gameTimer.cancel(); // Cancelar el temporizador para pausar
            enableSystemUI(); // Opcional: habilitar la interfaz de usuario del sistema
        } else {
            // Reanudar el temporizador desde donde se detuvo
            gameTimer = createTimer();
            gameTimer.start();
            disableSystemUI(); // Opcional: deshabilitar la interfaz de usuario del sistema
        }
    }

    private CountDownTimer createTimer() {
        return new CountDownTimer(Long.MAX_VALUE, 1000) {
            public void onTick(long millisUntilFinished) {
                if (isGamePaused) return;

                // Reducir el tiempo del jugador en turno
                if (isPlayerOneTurn) {
                    playerOneTimeLeft -= 1000;
                } else {
                    playerTwoTimeLeft -= 1000;
                }

                // Verificar si alguno de los jugadores se quedó sin tiempo
                if (playerOneTimeLeft <= 0 || playerTwoTimeLeft <= 0) {
                    onFinishGame();
                    return;
                }

                updateTimerTexts();
            }

            public void onFinish() {
                // Reproducir el sonido cuando el tiempo llega a cero
                if (!isGamePaused) {
                    mediaPlayer.start();
                }
            }

            private void onFinishGame() {
                isGameRunning = false;
                cancel();
                updateTimerTexts();
                startButton.setEnabled(true);
            }
        };
    }

    private void updateTimerTexts() {
        updateTimerText(playerOneTimeLeft, 1);
        updateTimerText(playerTwoTimeLeft, 2);
    }

    private void updateTimerText(long timeLeft, int playerId) {
        String timerText;
        if (timeLeft <= 0) {
            timerText = "-00:00"; // Mostrar "-00:00" cuando el tiempo llega a cero
        } else {
            timerText = String.format("%02d:%02d", (timeLeft / 1000) / 60, (timeLeft / 1000) % 60);
        }

        if (playerId == 1) {
            playerOneTimerView.setText(timerText);
        } else {
            playerTwoTimerView.setText(timerText);
        }
    }


    private void updateMoveCount() {
        whitePlayerMovesView.setText("Move: " + whitePlayerMoves);
        blackPlayerMovesView.setText("Move: " + blackPlayerMoves);
    }

    // Método para actualizar la cola de lecturas de aceleración
    private void updateAccelerationQueue(float newY) {
        if (accelerationQueue.size() >= WINDOW_SIZE) {
            accelerationQueue.poll(); // Elimina el elemento más antiguo si se alcanza el tamaño de la ventana
        }
        accelerationQueue.offer(newY); // Agrega la última lectura de aceleración
    }

    // Método para calcular el promedio móvil
    private float calculateMovingAverage() {
        float sum = 0;
        for (float y : accelerationQueue) {
            sum += y;
        }
        return sum / accelerationQueue.size();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!isGameRunning || isGamePaused || System.currentTimeMillis() - lastMoveTime < MOVE_THRESHOLD_TIME) return;

        float rawY = event.values[1]; // Lectura actual del acelerómetro en el eje Y

        // Aplicar el filtro de paso bajo
        filteredY = filteredY + ALPHA * (rawY - filteredY);

        // Verificar si la lectura excede el umbral
        if (Math.abs(filteredY) > THRESHOLD) {
            // Si es un golpe, ignorar esta lectura
            return;
        }

        // Actualizamos la cola con la última lectura de aceleración en el eje Y
        updateAccelerationQueue(filteredY);

        // Calculamos el promedio móvil de las últimas lecturas
        float averageY = calculateMovingAverage();

        if ((averageY > 0.07 && !isPlayerOneTurn) || (averageY < -0.07 && isPlayerOneTurn)) {
            lastMoveTime = System.currentTimeMillis();

            // Verificar si el tiempo restante es mayor que cero antes de aplicar el incremento
            if (isPlayerOneTurn && playerOneTimeLeft > 0) {
                playerOneTimeLeft += incrementWhite * 1000; // Incremento para blancas
                whitePlayerMoves++;
            } else if (!isPlayerOneTurn && playerTwoTimeLeft > 0) {
                playerTwoTimeLeft += incrementBlack * 1000; // Incremento para negras
                blackPlayerMoves++;
            }

            // Cambiar el turno después de aplicar el incremento
            isPlayerOneTurn = !isPlayerOneTurn;
            updateMoveCount();
            updateTimerTexts();
        }
    }



    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        gameTimer.cancel();
        // Restaurar la visibilidad de los botones de navegación
        //disableSystemUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        if (isGameRunning) {
            gameTimer.start();
            // Ocultar los botones de navegación

            disableSystemUI();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(STATE_PLAYER_ONE_TIME_LEFT, playerOneTimeLeft);
        outState.putLong(STATE_PLAYER_TWO_TIME_LEFT, playerTwoTimeLeft);
        outState.putInt(STATE_WHITE_PLAYER_MOVES, whitePlayerMoves);
        outState.putInt(STATE_BLACK_PLAYER_MOVES, blackPlayerMoves);
        outState.putBoolean(STATE_IS_PLAYER_ONE_TURN, isPlayerOneTurn);
        outState.putBoolean(STATE_IS_GAME_RUNNING, isGameRunning);
        outState.putBoolean(STATE_IS_GAME_PAUSED, isGamePaused);
        outState.putInt(STATE_INCREMENT_WHITE, incrementWhite); // Guardar incremento de blancas
        outState.putInt(STATE_INCREMENT_BLACK, incrementBlack); // Guardar incremento de negras
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SETTINGS_REQUEST && resultCode == RESULT_OK) {
            playerOneTimeLeft = data.getLongExtra(EXTRA_PLAYER_ONE_TIME, 30000);
            playerTwoTimeLeft = data.getLongExtra(EXTRA_PLAYER_TWO_TIME, 30000);
            incrementWhite = data.getIntExtra(EXTRA_INCREMENT_WHITE, 0); // Obtener incremento para blancas
            incrementBlack = data.getIntExtra(EXTRA_INCREMENT_BLACK, 0); // Obtener incremento para negras
            updateTimerTexts();
        }
    }
    private void handleMenuButton() {
        if (isGameRunning) {
            isGamePaused = true;
        }

        Intent intent = new Intent(MainActivity.this, MenuActivity.class);
        startActivity(intent);
    }

    // Agregar estos métodos para ocultar/restaurar los botones de navegación

    private void disableSystemUI() {
        View decorView = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE;
        decorView.setSystemUiVisibility(flags);
    }

    private void enableSystemUI() {
        View decorView = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        decorView.setSystemUiVisibility(flags);
    }

    // Método para habilitar o deshabilitar el modo avión
    private void toggleAirplaneMode() {
        // Verifica el estado actual del modo avión
        boolean isAirplaneModeOn = isAirplaneModeOn();

        // Habilita o deshabilita el modo avión
        setAirplaneMode(!isAirplaneModeOn);
    }

    // Método para verificar el estado del modo avión
    private boolean isAirplaneModeOn() {
        try {
            // Obtiene el estado actual del modo avión
            return Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON) == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para habilitar o deshabilitar el modo avión
    private void setAirplaneMode(boolean enabled) {
        try {
            // Habilita o deshabilita el modo avión
            Settings.Global.putInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, enabled ? 1 : 0);

            // Notifica al sistema que el modo avión ha cambiado
            Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
            intent.putExtra("state", enabled);
            sendBroadcast(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
